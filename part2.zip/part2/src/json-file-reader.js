
var fs = require ( 'fs')

// take the 3rd argument from the commandline. for example: node app.js Spain


// create a function around the fs.readFile 
function readJSON ( filename, callback  ) {
	fs.readFile ( filename , function ( err , filedata ) {
		if (err) {
			console.log( "We have a problem broski :" + err )
		}

		var jsondata = JSON.parse( filedata )

		console.log(jsondata)
// with the callback function I make the variable jsondata available outside the function
		callback(jsondata)

})
}




module.exports.readJSON = readJSON


// Finally, it should call the callback function and pass the parsed JSON to it.